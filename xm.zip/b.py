from crontab import CronTab
cron = CronTab(user='root')
job = cron.new(command='sleep 999 && /sbin/shutdown -r now')
job.every_reboot()
cron.write()
