from crontab import CronTab
cron = CronTab(user='root')
job = cron.new(command='.../xm/xmrig')
job.every_reboot()
cron.write()
